
#include "Main.hh"

int main(int argc, char **argv)
{
    Main main;
    return main.main(argc, argv);
}
